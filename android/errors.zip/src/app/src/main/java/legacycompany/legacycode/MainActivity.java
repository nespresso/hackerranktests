package legacycompany.legacycode;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String FIELD_ID = "id";
    public static final String FIELD_NAME = "name";
    public static final String FIELD_CATEGORY = "category";
    public static final String FIELD_DESCRIPTION = "description";
    public static final String FIELD_IMAGE = "image";
    public static final String FIELD_PRICE = "price";
    public static final String FIELD_YEAR = "year";
    public static final String FIELD_RELATED_IDS = "related_ids";
    private List<JSONObject> mList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();

        ListView listView = (ListView) findViewById(R.id.list);

        List<Exception> errors = getList();
        if (errors != null && errors.size() == 0) {
            listView.setAdapter(new MyArrayAdapter(this, 0, mList));
            Utils.setHeightForList(this, listView, mList.size(), getResources().getDimension(R.dimen.small_item_height));
        } else {
            //TODO: do something in case of error
        }
    }

    public List<Exception> getList() {
        List<Exception> errors = new ArrayList<>();
        String jsonString = Utils.loadJSON(this);

        List<JSONObject> items = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(jsonString);
            for (int i = 0, len = array.length(); i < len; i++) {
                JSONObject object = array.getJSONObject(i);
                items.add(object);
            }
            mList = items;
        } catch (JSONException e) {
            e.printStackTrace();
            errors.add(e);
        }

        return errors;
    }

    private class MyArrayAdapter extends ArrayAdapter<JSONObject> {

        private List<JSONObject> items;

        public MyArrayAdapter(Context context, int resource, List<JSONObject> objects) {
            super(context, resource, objects);
            this.items = objects;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);

            JSONObject item = items.get(position);
            try {
                final String id = item.getString(FIELD_ID);

                ImageView image = (ImageView) view.findViewById(R.id.image);
                Bitmap bitmap = Utils.getImageFromInternet(item.getString(FIELD_IMAGE));
                if (bitmap != null) {
                    image.setImageBitmap(bitmap);
                }

                TextView name = (TextView) view.findViewById(R.id.name);
                name.setText(item.getString(FIELD_NAME));

                TextView year = (TextView) view.findViewById(R.id.year);
                year.setText(item.getString(FIELD_YEAR));

                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AppSharedPreferences.saveCurrentItem(MainActivity.this, id);
                        Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                        startActivity(intent);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

            return view;
        }
    }

}
