package legacycompany.legacycode;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DetailsActivity extends AppCompatActivity {

    private ImageView imageViewImage;
    private TextView textViewName;
    private TextView textViewYear;
    private TextView textViewPrice;
    private TextView textViewDescription;
    private LinearLayout containerRelated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        imageViewImage = (ImageView) findViewById(R.id.image);
        textViewName = (TextView) findViewById(R.id.name);
        textViewYear = (TextView) findViewById(R.id.year);
        textViewPrice = (TextView) findViewById(R.id.price);
        textViewDescription = (TextView) findViewById(R.id.description);
        containerRelated = (LinearLayout) findViewById(R.id.container_related);
    }

    @Override
    protected void onResume() {
        super.onResume();

        String currentItem = AppSharedPreferences.getCurrentItem(this);
        JSONObject item = getItemById(currentItem);

        try {
            imageViewImage.setImageBitmap(Utils.getImageFromInternet(item.getString(MainActivity.FIELD_IMAGE)));
            textViewName.setText(item.getString(MainActivity.FIELD_NAME));
            textViewYear.setText(item.getString(MainActivity.FIELD_YEAR));
            textViewPrice.setText(item.getString(MainActivity.FIELD_PRICE));
            textViewDescription.setText(item.getString(MainActivity.FIELD_DESCRIPTION));

            // set related list image and text
            JSONArray relatedIds = item.getJSONArray(MainActivity.FIELD_RELATED_IDS);
            for (int i = 0, len = relatedIds.length(); i < len; i++) {
                final String id = (String) relatedIds.get(0);
                JSONObject relatedItem = getItemById(id);

                View itemVIew = getLayoutInflater().inflate(R.layout.grid_item, null, false);
                ImageView gridItemImageView = (ImageView) itemVIew.findViewById(R.id.image);
                Bitmap bitmap = Utils.getImageFromInternet(relatedItem.getString(MainActivity.FIELD_IMAGE));
                if (bitmap != null) {
                    gridItemImageView.setImageBitmap(bitmap);
                }
                TextView gridItemTextView = (TextView) itemVIew.findViewById(R.id.text);
                gridItemTextView.setText(relatedItem.getString(MainActivity.FIELD_NAME));

                containerRelated.addView(itemVIew);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public JSONObject getItemById(String id) {
        String jsonString = Utils.loadJSON(this);

        try {
            JSONArray array = new JSONArray(jsonString);
            for (int i = 0, len = array.length(); i < len; i++) {
                JSONObject object = array.getJSONObject(i);
                if (object.getString(MainActivity.FIELD_ID).equals(id)) {
                    return object;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
}
