package legacycompany.legacycode;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.io.IOException;
import java.io.InputStream;

public class Utils {

    public static Bitmap getImageFromInternet(String url) {
        Bitmap mIcon11 = null;
        try {
            InputStream in = new java.net.URL(url).openStream();
            mIcon11 = BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mIcon11;
    }

    public static String loadJSON(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static void setHeightForList(Activity activity, ListView list, int count, float itemHeight) {
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) list.getLayoutParams();
        params.height = (int) ((Math.ceil(itemHeight) + Math.ceil(activity.getResources().getDimension(R.dimen.divider_height))) * count);
        list.setLayoutParams(params);
    }
}
