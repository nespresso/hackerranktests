package legacycompany.legacycode;

import android.content.Context;
import android.content.SharedPreferences;

public class AppSharedPreferences {

    private static final String MY_PREFS = "my_prefs";

    public static void saveCurrentItem(Context context, String id) {
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS, Context.MODE_PRIVATE).edit();
        editor.putString("currentItem", id);
        editor.commit();
    }

    public static String getCurrentItem(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS, Context.MODE_PRIVATE);
        return prefs.getString("currentItem", null);
    }
}
